﻿using System.Data.SqlClient;
namespace part_two_API.Database
{//start of namespace
    public class UserDatabase
    {//start of class

        
        // Register user
        public string RegisterUser(string fullname, string email, string role, string hashedPassword)
        {
            string message = string.Empty;
            string connection_string = @"Server=localhost\SQLEXPRESS;Database=Prog;Trusted_Connection=True;";

            try
            {
                using (SqlConnection connect = new SqlConnection(connection_string))
                {
                    connect.Open();

                    // Insert into Users table and get new UserID
                    string query = @"INSERT INTO Users (UserName, UserEmail, HashedPassword, Role)
                             OUTPUT INSERTED.UserID
                             VALUES (@UserName, @UserEmail, @HashedPassword, @Role)";

                    SqlCommand run_query = new SqlCommand(query, connect);
                    run_query.Parameters.AddWithValue("@UserName", fullname);
                    run_query.Parameters.AddWithValue("@UserEmail", email);
                    run_query.Parameters.AddWithValue("@HashedPassword", hashedPassword);
                    run_query.Parameters.AddWithValue("@Role", role);

                    int newUserId = (int)run_query.ExecuteScalar();

                    // Insert into Organiser or Participant depending on role
                    if (role == "Organiser")
                    {
                        string insertOrganiser = @"INSERT INTO Organiser (OrganiserName, Email, UserID)
                                           VALUES (@OrganiserName, @Email, @UserID)";
                        SqlCommand cmdOrg = new SqlCommand(insertOrganiser, connect);
                        cmdOrg.Parameters.AddWithValue("@OrganiserName", fullname);
                        cmdOrg.Parameters.AddWithValue("@Email", email);
                        cmdOrg.Parameters.AddWithValue("@UserID", newUserId);
                        cmdOrg.ExecuteNonQuery();
                    }
                    else if (role == "Participant")
                    {
                        string insertParticipant = @"INSERT INTO Participant (ParticipantName, Email, RaceNumber, UserID)
                                             VALUES (@ParticipantName, @Email, @RaceNumber, @UserID)";
                        SqlCommand cmdPart = new SqlCommand(insertParticipant, connect);
                        cmdPart.Parameters.AddWithValue("@ParticipantName", fullname);
                        cmdPart.Parameters.AddWithValue("@Email", email);
                        cmdPart.Parameters.AddWithValue("@RaceNumber", "R" + newUserId); // auto‑generate race number
                        cmdPart.Parameters.AddWithValue("@UserID", newUserId);
                        cmdPart.ExecuteNonQuery();
                    }

                    message = "User registered successfully with role: " + role;
                }
            }
            catch (SqlException ex)
            {
                message = "Database error: " + ex.Message;
            }
            catch (Exception ex)
            {
                message = "Unexpected error: " + ex.Message;
            }

            return message;
        }

        // Login user
        public string LoginUser(string email, string password)
        {
            string message = "Invalid login";
            string connection_string = @"Server=localhost\SQLEXPRESS;Database=Prog;Trusted_Connection=True;";

            try
            {
                using (SqlConnection connect = new SqlConnection(connection_string))
                {
                    string query = @"SELECT UserID, HashedPassword, Role FROM Users WHERE UserEmail = @UserEmail";
                    connect.Open();

                    SqlCommand run_query = new SqlCommand(query, connect);
                    run_query.Parameters.AddWithValue("@UserEmail", email);

                    using (SqlDataReader reader = run_query.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string storedHash = reader["HashedPassword"].ToString();
                            // // new Addition: Extracting role and userId so the controller can store them in the session
                            string role = reader["Role"].ToString();
                            int userId = Convert.ToInt32(reader["UserID"]);

                            

                            bool isValid = BCrypt.Net.BCrypt.Verify(password, storedHash);
                            if (isValid)
                                message = $"Login successful, role: {role}, userId: {userId}";
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                message = "Database error: " + ex.Message;
            }
            catch (Exception ex)
            {
                message = "Unexpected error: " + ex.Message;
            }

            return message;
        }







    }//end of class
}//end of namespace
