﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using part_two_API.Controllers;
using part_two_API.Database;
using part_two_API.Model;

namespace ApiUnitTests
{//start of namespace
    public class UnitTest1
    {//start of class

        // 1. User Registration and Login Tests (Requirement: Registration & Login)[cite: 1]

        [Fact]
        public void Register_ValidUser_ReturnsOkResult()
        {//start of test method

            // Arrange
            var controller = new AutheController();

            // Act - Registering a new participant mimicking schema rules
            var result = controller.Register("Thabo Nkosi", "thabo@mail.com", AutheController.roles.Participant, "pass123");

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.NotNull(okResult.Value);

        }//end of test method





        public class FakeSession : ISession
        {
            private readonly Dictionary<string, byte[]> _sessionStorage = new Dictionary<string, byte[]>();
            public bool IsAvailable => true;
            public string Id => "TestSessionId";
            public IEnumerable<string> Keys => _sessionStorage.Keys;
            public void Clear() => _sessionStorage.Clear();
            public Task CommitAsync(CancellationToken cancellationToken = default) => Task.CompletedTask;
            public Task LoadAsync(CancellationToken cancellationToken = default) => Task.CompletedTask;
            public void Remove(string key) => _sessionStorage.Remove(key);
            public void Set(string key, byte[] value) => _sessionStorage[key] = value;
            public bool TryGetValue(string key, out byte[] value) => _sessionStorage.TryGetValue(key, out value);
        }

        public class FakeSessionFeature : Microsoft.AspNetCore.Http.Features.ISessionFeature
        {
            public ISession Session { get; set; }
            public FakeSessionFeature(ISession session) => Session = session;
        }






        [Fact]
        public void Login_InvalidCredentials_ReturnsUnauthorized()
        {//start of Login_InvalidCredentials_ReturnsUnauthorized meth

            // Arrange
            var controller = new AutheController();

            // Act - Passing non-existent or incorrect email/password combo
            var result = controller.Login("wronguser@raceday.com", "WrongPassword");

            // Assert
            var unauthorizedResult = Assert.IsType<UnauthorizedObjectResult>(result);
            Assert.NotNull(unauthorizedResult.Value);

        }//end of Login_InvalidCredentials_ReturnsUnauthorized


        // 2. Event Management Tests (Requirement: Organisers managing events)[cite: 1]

        [Fact]
        public void GetEvents_ReturnsOkWithEventList()
        {//start of Getevents_returnsokwitheventlist

            // Arrange
            var controller = new EventController();

            // Act - Retrieves list including seeded events like 'Joburg Marathon'
            var result = controller.GetEvents();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.NotNull(okResult.Value);

        }//end of getEvents_returnsokWithEventList

        [Fact]
        public void CreateEvent_ValidEvent_ReturnsOkResult()
        {//start of createevent_ValidEvenet_ReturnsOkResult

            // Arrange
            var controller = new EventController();

            // Using exact properties from the Event table schema
            var newEvent = new Event
            {
                EventName = "Pretoria Half Marathon",
                EventDescription = "Annual scenic run",
                EventType = "Run",
                EventDate = DateTime.Parse("2026-11-20"),
                PlaceOfTheEvent = "Pretoria",
                CategoryID = 1,
                OrganiserID = 1 // Linked to Organiser 'Juice Wrld'
            };

            // Act
            var result = controller.CreateEvent(newEvent);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.NotNull(okResult.Value);


        }//end of createevent_ValidEvenet_ReturnsOkResult


        [Fact]
        public void Logout_ClearsSession_ReturnsOkResult()
        {
            // Arrange
            var controller = new AutheController();
            var sessionMock = new FakeSession();
            var httpContextMock = new DefaultHttpContext();
            httpContextMock.Features.Set<Microsoft.AspNetCore.Http.Features.ISessionFeature>(new FakeSessionFeature(sessionMock));
            controller.ControllerContext = new ControllerContext
            {
                HttpContext = httpContextMock
            };

            // Act
            var result = controller.Logout();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.NotNull(okResult.Value);
        }//logout_clearsession_returnsokresult

        // 3. Role-Based Access & Rejection Tests 
        // (Requirement: Different roles rejected when accessing invalid profiles)[cite: 1]

        [Fact]
        public void GetParticipantProfile_NonExistentUserId_ReturnsNotFound()
        {//start of Getparticipantprofile_NonExistentUserId_ReturnSnotfound

            // Arrange
            var controller = new AutheController();
            int invalidUserId = 9999; // User ID not matching any participant

            // Act
            var result = controller.GetParticipantProfile(invalidUserId);

            // Assert
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
            Assert.Equal("Profile not found", notFoundResult.Value);

        }//end of Getparticipantprofile_NonExistentUserId_ReturnSnotfound


        [Fact]
        public void GetOrganiserProfile_NonExistentUserId_ReturnsNotFound()
        {//start of getOrganiserProfile_nonExistentUserId_return

            // Arrange
            var controller = new AutheController();
            int invalidUserId = 9999; // User ID not matching any organiser

            // Act
            var result = controller.GetOrganiserProfile(invalidUserId);

            // Assert
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
            Assert.Equal("Profile not found", notFoundResult.Value);

        }//end of getOrganiserProfile_nonExistentUserId_return

        // 4. Event Enrollments Tests 
        // (Requirement: Participants can enrol and it's recorded)[cite: 1]

        [Fact]
        public void CreateEnrollment_ValidEnrollment_ReturnsOkResult()
        {//start of createEnrollment_validenrollment_returnsokresult

            // Arrange
            var db = new EnrollmentDatabase();
            var controller = new EnrollmentController(db);

            // Matching schema: UserID 2 (Participant), EventID 1 ('Joburg Marathon'), CategoryID 1
            var enrollment = new Enrollment
            {
                EnrollmentDate = DateTime.Now,
                EnrollmentStatus = "Confirmed",
                UserID = 2,
                EventID = 1,
                CategoryID = 1
            };

            // Act
            var result = controller.CreateEnrollment(enrollment);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.NotNull(okResult.Value);

        }//end of createEnrollment_validenrollment_returnsokresult

        [Fact]
        public void GetEnrollmentsByEvent_ValidEventId_ReturnsOkResult()
        {//start of getEnrollmentsbyEvent_validEventID_returnOkResult()

            // Arrange
            var db = new EnrollmentDatabase();
            var controller = new EnrollmentController(db);
            int eventId = 1; // Joburg Marathon event ID

            // Act
            var result = controller.GetEnrollmentsByEvent(eventId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.NotNull(okResult.Value);

        }//end of getEnrollmentsbyEvent_validEventID_returnOkResult()


    }//end of class

}//end of namespace 
