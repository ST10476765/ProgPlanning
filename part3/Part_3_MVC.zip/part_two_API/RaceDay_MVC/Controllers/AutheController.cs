﻿using Microsoft.AspNetCore.Mvc;
using RaceDay_MVC.Models;

namespace RaceDay_MVC.Controllers
{
    public class AutheController : Controller
    {
        // public IActionResult Index()
        // {
        //     return View();
        // }

        // Login Page

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        //Register Page

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }


        // ADDED: Register User Through API
        [HttpPost]
        public async Task<IActionResult> Register(RegisterModel model)
        {
            HttpClient client = new HttpClient();

            string url =
                $"https://localhost:7140/api/Authe/register?" +
                $"UserName={model.UserName}" +
                $"&UserEmail={model.UserEmail}" +
                $"&Role={model.Role}" +
                $"&password={model.Password}";

            var response =
                await client.PostAsync(url, null);

            if (response.IsSuccessStatusCode)
            {
                TempData["Message"] =
                    "Registration Successful";

                return RedirectToAction("Login");
            }

            TempData["Message"] =
                "Registration Failed";

            return View(model);
        }




        // ADDED: Login Through API
        [HttpPost]
        public async Task<IActionResult> Login(LoginModel model)
        {
            HttpClient client = new HttpClient();

            string url =
                $"https://localhost:7140/api/Authe/login?" +
                $"UserEmail={model.UserEmail}" +
                $"&password={model.Password}";

            var response =
                await client.PostAsync(url, null);

            if (!response.IsSuccessStatusCode)
            {
                TempData["Message"] = "Invalid Login";

                return View(model);
            }

            var result =
                await response.Content.ReadAsStringAsync();

            // ADDED: Store UserID In Session
            var match = System.Text.RegularExpressions.Regex.Match(
                result,
                @"userId:\s*(\d+)"
            );

            if (match.Success)
            {
                HttpContext.Session.SetString(
                    "UserID",
                    match.Groups[1].Value
                );
            }

            // ADDED: Store Email In Session
            HttpContext.Session.SetString(
                "UserEmail",
                model.UserEmail
            );

            // ADDED: Store Role In Session
            if (result.Contains("Organiser"))
            {
                HttpContext.Session.SetString(
                    "UserRole",
                    "Organiser"
                );
            }
            else
            {
                HttpContext.Session.SetString(
                    "UserRole",
                    "Participant"
                );
            }

            TempData["Message"] = "Login Successful";

            return RedirectToAction(
                "Index",
                "Home"
            );
        }


        // Logout
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();

            return RedirectToAction(
                "Login",
                "Authe"
            );
        }




    }
}
