﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using System.Text;
using System.Text.Json;
using RaceDay_MVC.Models;

namespace RaceDay_MVC.Controllers
{
    public class ResultController : Controller
    {//start of class

        // Display Result Form
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // ADDED: Save Result Through API
        [HttpPost]
        public async Task<IActionResult> Create(Result result)
        {
            HttpClient client = new HttpClient();

            string json =
                JsonSerializer.Serialize(result);

            StringContent content =
                new StringContent(
                    json,
                    Encoding.UTF8,
                    "application/json"
                );

            var response =
                await client.PostAsync(
                    "https://localhost:7140/api/Result/create",
                    content
                );

            if (response.IsSuccessStatusCode)
            {
                TempData["Message"] =
                    "Result Captured Successfully";

                return RedirectToAction(
                    "Create"
                );
            }

            TempData["Message"] =
                "Failed To Capture Result";

            return View(result);
        }

        public async Task<IActionResult> Index(int eventId)
        {
            HttpClient client = new HttpClient();

            var response =
                await client.GetAsync(
                    $"https://localhost:7140/api/Result/event/{eventId}"
                );

            var json =
                await response.Content.ReadAsStringAsync();

            var results =
                JsonSerializer.Deserialize<List<Result>>(
                    json,
                    new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

            return View(results);
        }

        // Participant My Results
        public async Task<IActionResult> MyResults()
        {
            string userId =
                HttpContext.Session.GetString("UserID");

            HttpClient client = new HttpClient();

            var response =
                await client.GetAsync(
                    $"https://localhost:7140/api/Result/participant/{userId}"
                );

            var json =
                await response.Content.ReadAsStringAsync();

            var results =
                JsonSerializer.Deserialize<List<Result>>(
                    json,
                    new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

            return View(results);
        }

    }// end of class

}// end of namespace
