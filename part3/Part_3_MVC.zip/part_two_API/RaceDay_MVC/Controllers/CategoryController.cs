﻿using Microsoft.AspNetCore.Mvc;
using RaceDay_MVC.Models;
using System.Text;
using System.Text.Json;

namespace RaceDay_MVC.Controllers
{
    public class CategoryController : Controller
    {


        // ADDED: View Categories

        public async Task<IActionResult> Index()
        {
            HttpClient client = new HttpClient();

                var response =
                await client.GetAsync(
                    "https://localhost:7140/api/Category/all"
                );

                var json =
                await response.Content.ReadAsStringAsync();

                var categories =
                JsonSerializer.Deserialize<List<Category>>(
                    json,
                    new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

                return View(categories);

        }//

        // ADDED: Load Create Category Page

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // ADDED: Create Category Through API

        [HttpPost]
        public async Task<IActionResult> Create(Category category)
        {
            HttpClient client = new HttpClient();

            string json =
                JsonSerializer.Serialize(category);

            StringContent content =
                new StringContent(
                    json,
                    Encoding.UTF8,
                    "application/json"
                );

            var response =
                await client.PostAsync(
                    "https://localhost:7140/api/Category/create",
                    content
                );

            return RedirectToAction("Index");
        }

    }//end of class
}//end of namespace
