﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using RaceDay_MVC.Models;
using System.Text.Json;

namespace RaceDay_MVC.Controllers
{
    public class EventController : Controller
    {

        public async Task<IActionResult> Index()
        {

            // ADDED: Block access if user is not logged in
            if (HttpContext.Session.GetString("UserRole") == null)
            {
                return RedirectToAction(
                    "Login",
                    "Authe"
                );
            }

            HttpClient client = new HttpClient();

            var response = await client.GetAsync(
                "https://localhost:7140/api/Event/all"
            );

            var json = await response.Content.ReadAsStringAsync();

            Console.WriteLine(json);

            var events = JsonSerializer.Deserialize<List<Event>>(
                json,
                new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

            return View(events);
        }

        //Display Create Event Page
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }


        // ADDED: Create Event Through API
        [HttpPost]
        public async Task<IActionResult> Create(Event ev)
        {
            HttpClient client = new HttpClient();

            string json =
                JsonSerializer.Serialize(ev);

            StringContent content =
                new StringContent(
                    json,
                    System.Text.Encoding.UTF8,
                    "application/json"
                );

            var response =
                await client.PostAsync(
                    "https://localhost:7140/api/Event/create",
                    content
                );

            if (response.IsSuccessStatusCode)
            {
                TempData["Message"] =
                    "Event Created Successfully";

                return RedirectToAction("Index");
            }

            TempData["Message"] =
                "Failed To Create Event";

            return View(ev);
        }

        // ADDED: Delete Event Through API
        public async Task<IActionResult> Delete(int id)
        {
            HttpClient client = new HttpClient();

            var response =
                await client.DeleteAsync(
                    $"https://localhost:7140/api/Event/delete/{id}"
                );

            if (response.IsSuccessStatusCode)
            {
                TempData["Message"] =
                    "Event Deleted Successfully";
            }
            else
            {
                TempData["Message"] =
                    "Failed To Delete Event";
            }

            return RedirectToAction("Index");
        }

        //Load Event For Editing
        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            HttpClient client = new HttpClient();

            var response =
                await client.GetAsync(
                    $"https://localhost:7140/api/Event/{id}"
                );

            var json =
                await response.Content.ReadAsStringAsync();

            var ev =
                JsonSerializer.Deserialize<Event>(
                    json,
                    new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

            return View(ev);
        }


        //Save Edited Event

        [HttpPost]
        public async Task<IActionResult> Edit(Event ev)
        {
            HttpClient client = new HttpClient();

            string json =
                JsonSerializer.Serialize(ev);

            StringContent content =
                new StringContent(
                    json,
                    System.Text.Encoding.UTF8,
                    "application/json"
                );

            var response =
                await client.PutAsync(
                    "https://localhost:7140/api/Event/update",
                    content
                );

            if (response.IsSuccessStatusCode)
            {
                TempData["Message"] =
                    "Event Updated Successfully";

                return RedirectToAction("Index");
            }

            TempData["Message"] =
                "Failed To Update Event";

            return View(ev);
        }

        



        //public IActionResult Index()
        //{
        //   return View();
        //}
    }
}
