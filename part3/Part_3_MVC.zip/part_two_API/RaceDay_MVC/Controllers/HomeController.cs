using Microsoft.AspNetCore.Mvc;
using RaceDay_MVC.Models;
using System.Diagnostics;
using System.Text.Json;

namespace RaceDay_MVC.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {

            ViewBag.Role =
            HttpContext.Session.GetString("UserRole");

            return View();

        }

        

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
