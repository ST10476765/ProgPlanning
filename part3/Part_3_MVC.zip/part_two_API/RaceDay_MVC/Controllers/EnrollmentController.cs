﻿using Microsoft.AspNetCore.Mvc;
using RaceDay_MVC.Models;
using System.Text.Json;

namespace RaceDay_MVC.Controllers
{
    public class EnrollmentController : Controller
    {

        // ADDED: View Enrollments For A Specific Event

        public async Task<IActionResult> Index(int eventId)
        {
            HttpClient client = new HttpClient();

                var response =
                await client.GetAsync(
                    $"https://localhost:7140/api/Enrollment/event/{eventId}"
                );

                var json =
                await response.Content.ReadAsStringAsync();

                var enrollments =
                JsonSerializer.Deserialize<List<Enrollment>>(
                    json,
                    new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

               return View(enrollments);

        }

        // ADDED: Display Enrollment Page
        [HttpGet]
        public IActionResult Create(int eventId)
        {
            Enrollment enrollment = new Enrollment();

            // ADDED: Pre-populate EventID
            enrollment.EventID = eventId;

            return View(enrollment);
        }

        // ADDED, Save Enrollment Through API
        [HttpPost]
        public async Task<IActionResult> Create(Enrollment enrollment)
        {
            HttpClient client = new HttpClient();

            string json =
                JsonSerializer.Serialize(enrollment);

            StringContent content =
                new StringContent(
                    json,
                    System.Text.Encoding.UTF8,
                    "application/json"
                );

            var response =
                await client.PostAsync(
                    "https://localhost:7140/api/Enrollment/create",
                    content
                );

            if (response.IsSuccessStatusCode)
            {
                TempData["Message"] =
                    "Enrollment Successful";

                return RedirectToAction(
                    "Index",
                    "Event"
                );
            }

            return View(enrollment);
        }



        //My Enrollments
        public async Task<IActionResult> MyEnrollments()
        {
            string userId =
                HttpContext.Session.GetString("UserID");

            HttpClient client = new HttpClient();

            var response =
                await client.GetAsync(
                    $"https://localhost:7140/api/Enrollment/user/{userId}"
                );

            var json =
                await response.Content.ReadAsStringAsync();

            var enrollments =
                JsonSerializer.Deserialize<List<Enrollment>>(
                    json,
                    new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

            return View(enrollments);
        }

    }// end of class

}// end of namespace
