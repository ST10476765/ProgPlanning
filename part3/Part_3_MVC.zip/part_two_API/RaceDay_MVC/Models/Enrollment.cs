﻿namespace RaceDay_MVC.Models
{
    public class Enrollment
    {
        public int EnrollmentID { get; set; }

        public DateTime EnrollmentDate { get; set; }

        public string EnrollmentStatus { get; set; }

        public int UserID { get; set; }

        public int EventID { get; set; }

        public int CategoryID { get; set; }
    }
}
