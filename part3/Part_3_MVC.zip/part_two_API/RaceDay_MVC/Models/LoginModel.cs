﻿namespace RaceDay_MVC.Models
{//start of namespace
    public class LoginModel
    {//start of class

        public string UserEmail { get; set; }

        public string Password { get; set; }

    }//end of class


}//end of namespace
