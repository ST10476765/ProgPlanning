﻿namespace RaceDay_MVC.Models
{
    public class Result
    {
        public int ResultID { get; set; }

        public int EnrollmentID { get; set; }

        public TimeSpan FinishTime { get; set; }

        public int PodiumPlacement { get; set; }

    }
}
