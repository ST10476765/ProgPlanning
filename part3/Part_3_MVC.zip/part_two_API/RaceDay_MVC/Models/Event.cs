﻿namespace RaceDay_MVC.Models
{
    public class Event
    {// start of class
        public int EventID { get; set; }
        public string EventName { get; set; }
        public string EventDescription { get; set; }
        public string EventType { get; set; } // Run, Walk, Cycle
        public DateTime EventDate { get; set; }
        public string PlaceOfTheEvent { get; set; }
        public int CategoryID { get; set; }
        public int OrganiserID { get; set; }  // FK to Organiser

    }//end of class
}
