﻿namespace RaceDay_MVC.Models
{
    public class Participant
    {
        public int ParticipantID { get; set; }

        public string ParticipantName { get; set; }

        public string CellNumber { get; set; }

        public string Email { get; set; }

        public string RaceNumber { get; set; }

        public int Age { get; set; }

        public string Gender { get; set; }

        public int UserID { get; set; }
    }
}
