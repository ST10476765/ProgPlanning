﻿namespace RaceDay_MVC.Models
{// start of namespace
    public class Category
    {
        public int CategoryID { get; set; }

        public string CategoryDescription { get; set; }

        public string Distance { get; set; }

        public int OrganiserID { get; set; }



    }// end of class
}// end of namespace
