﻿namespace RaceDay_MVC.Models
{
    public class RegisterModel
    {//start of class

        public string UserName { get; set; }

        public string UserEmail { get; set; }

        public string Password { get; set; }

        public string Role { get; set; }


    }//end of class


}//end of namespace
