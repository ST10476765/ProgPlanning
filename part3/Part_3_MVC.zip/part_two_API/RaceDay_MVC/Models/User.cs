﻿namespace RaceDay_MVC.Models
{// start of namespace
    public class User
    {// start of class

        public int UserID { get; set; }

        public string UserName { get; set; }

        public string UserEmail { get; set; }

        public string Role { get; set; }

        public string HashedPassword { get; set; }

    }//end of class

}// end of namespace
