﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using part_two_API.Database;
using part_two_API.Model;

namespace part_two_API.Controllers
{//start of namespace
    [Route("api/[controller]")]
    [ApiController]
    public class EventController : ControllerBase
    {//start of class


        EventDatabase eventDb = new EventDatabase();

        //View all events
        [HttpGet("all")]
        public IActionResult GetEvents()
        {
            var events = eventDb.GetAllEvents();
            return Ok(events);
        }

        // Create event
        [HttpPost("create")]
        public IActionResult CreateEvent(Event ev)
        {
            string message = eventDb.CreateEvent(ev);
            return Ok(new { message });

        }//end of create event

        // 🧠 Update event
        [HttpPut("update")]
        public IActionResult UpdateEvent(Event ev)
        {
            string message = eventDb.UpdateEvent(ev);
            return Ok(new { message });
        }

        // 🧠 Delete event
        [HttpDelete("delete/{eventId}")]
        public IActionResult DeleteEvent(int eventId)
        {
            string message = eventDb.DeleteEvent(eventId);
            return Ok(new { message });
        }//end of Delete event






    }//end of class


}//end of namespace
