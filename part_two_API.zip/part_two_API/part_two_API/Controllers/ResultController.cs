﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using part_two_API.Database;
using part_two_API.Model;

namespace part_two_API.Controllers
{//start of namespace
    [Route("api/[controller]")]
    [ApiController]
    public class ResultController : ControllerBase
    {//start of class

        private readonly ResultDatabase _db;

        public ResultController(ResultDatabase db)
        {
            _db = db;
        }//end of DI resultController constructor

        [HttpPost("create")]
        public IActionResult CreateResult([FromBody] Result result)
        {
            _db.CreateResult(result);
            return Ok(new { message = "Result captured successfully" });

        }//end of createResult meth

        [HttpGet("participant/{userId}")]
        public IActionResult GetResultsByParticipant(int userId)
        {
            var results = _db.GetResultsByParticipant(userId);
            return Ok(results);
        }//end of getresult meth


    }//end of class
}//end of namespace
