﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using part_two_API.Database;
using part_two_API.Model;
using static part_two_API.Controllers.AutheController;

namespace part_two_API.Controllers
{//start of namespace 
    [Route("api/[controller]")]
    [ApiController]
    public class AutheController : ControllerBase
    {//start of class


        private readonly UserDatabase dbase;

        public AutheController()
        {
            dbase = new UserDatabase();
        }

        public enum roles
        {//start of enum
            Participant,
            Organiser

        }//end of enum


        [HttpPost("register")]
        public IActionResult Register(string UserName, string UserEmail, roles Role, string password)
        { //start of Register meth
            // Hash the password before saving
            string hashedPassword = BCrypt.Net.BCrypt.HashPassword(password);

            string message = dbase.RegisterUser(UserName, UserEmail, Role.ToString(), hashedPassword);

            return Ok(new { message, role = Role.ToString() });
        }//end of Register meth


        // Login endpoint
        [HttpPost("login")]
        public IActionResult Login(string UserEmail, string password)
        {//start of login meth
            string message = dbase.LoginUser(UserEmail, password);

            // If the message contains "Invalid", treat it as failed login
            if (message.Contains("Invalid"))
                return Unauthorized(message);

            return Ok(new { message });
        }//end of login meth



        ParticipantDatabase participantDb = new ParticipantDatabase();

        //View Participant Profile
        [HttpGet("profile/participant/{userId}")]
        public IActionResult GetParticipantProfile(int userId)
        {
            var profile = participantDb.GetParticipantProfile(userId);
            if (profile == null)
                return NotFound("Profile not found");

            return Ok(profile);

        }//end of getparticipantproflie meth


        //Update Participant Profile
        [HttpPut("profile/participant/update")]
        public IActionResult UpdateParticipantProfile(int userId, int age, string gender, string cellnumber)
        {// start of UpdateParticipantProfile meth

            string message = participantDb.UpdateParticipantProfile(userId, age, gender, cellnumber);
            return Ok(new { message });

        }// end of UpdateParticipantProfile meth



        //Orgainser Profile
        OrganiserDatabase organiserDb = new OrganiserDatabase();

        // View Organiser Profile
        [HttpGet("profile/organiser/{userId}")]
        public IActionResult GetOrganiserProfile(int userId)
        {
            var profile = organiserDb.GetOrganiserProfile(userId);
            if (profile == null)
                return NotFound("Profile not found");

            return Ok(profile);
        }


        // Update Organiser Profile
        [HttpPut("profile/organiser/update")]
        public IActionResult UpdateOrganiserProfile(int userId, int age, string gender, string cellnumber)
        {
            string message = organiserDb.UpdateOrganiserProfile(userId, age, gender, cellnumber);
            return Ok(new { message });
        }


    }//end of class

}//end of namespace
