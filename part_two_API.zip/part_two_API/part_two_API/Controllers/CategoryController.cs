﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using part_two_API.Database;
using part_two_API.Model;

namespace part_two_API.Controllers
{//start of namespace

    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {//start of class

        private readonly CategoryDatabase _db;

        public CategoryController(CategoryDatabase db)
        {
            _db = db;
        }//end of controller constructor

        [HttpPost("create")]
        public IActionResult CreateCategory([FromBody] Category category)
        {
            _db.CreateCategory(category);
            return Ok(new { message = "Category created successfully" });
        }//end of Createcatergory method

        [HttpGet("all")]
        public IActionResult GetAllCategories()
        {
            var categories = _db.GetAllCategories();
            return Ok(categories);

        }//end of getallcategories methods


    }//end of class
}//end of namespace
