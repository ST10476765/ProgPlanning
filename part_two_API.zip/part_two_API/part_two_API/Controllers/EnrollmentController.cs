﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using part_two_API.Database;
using part_two_API.Model;

namespace part_two_API.Controllers
{//start of namespace
    [Route("api/[controller]")]
    [ApiController]
    public class EnrollmentController : ControllerBase
    {//start of class

        private readonly EnrollmentDatabase _db;

        public EnrollmentController(EnrollmentDatabase db)
        {
            _db = db;
        }

        [HttpPost("create")]
        public IActionResult CreateEnrollment([FromBody] Enrollment enrollment)
        {
            _db.CreateEnrollment(enrollment);
            return Ok(new { message = "Enrollment created successfully" });

        }//end of createEnrollment


        [HttpGet("event/{eventId}")]
        public IActionResult GetEnrollmentsByEvent(int eventId)
        {
            var enrollments = _db.GetEnrollmentsByEvent(eventId);
            return Ok(enrollments);

        }//end of getenrollment meth


    }//end of class

}//end of namespace
