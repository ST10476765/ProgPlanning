﻿namespace part_two_API.Model
{//start of namespace
    public class Organiser
    {//start of class

        public int OrganiserID { get; set; }
        public string OrganiserName { get; set; }
        public string CellNumber { get; set; }
        public string Email { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }
        public int UserID { get; set; } // FK to Users


    }//end of class

}//end of namespace
