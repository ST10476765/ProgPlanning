﻿namespace part_two_API.Model
{//start of namespace
    public class Result
    {//start of class

        public int ResultID { get; set; }
        public int EnrollmentID { get; set; } //Foreign Key
        public TimeSpan FinishTime { get; set; }
        public int PodiumPlacement { get; set; }

    }//end of class

}//end of namespace
