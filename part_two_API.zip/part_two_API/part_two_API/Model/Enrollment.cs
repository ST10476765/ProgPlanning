﻿using System.Security.Cryptography.Xml;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace part_two_API.Model
{//start of namespace 
    public class Enrollment
    {//start of class

        public int EnrollmentID { get; set; }
        public DateTime EnrollmentDate { get; set; }
        public string EnrollmentStatus { get; set; } // Run, Walk, Cycle
        public int UserID { get; set; }  // Foreign key
        public int EventID { get; set; }  // Foregin key
        public int CategoryID { get; set; }  // FK → Category


    }//end of class

}//end of namespace
