﻿using System.Security.Cryptography.Xml;

namespace part_two_API.Model
{//start of namespace
    public class Category
    {//start of class

        public int CategoryID { get; set; }
        public string CategoryDescription { get; set; }
        public string Distance { get; set; }
        public int OrganiserID { get; set; }    // FK


    }//end of class

}//end of namespace
