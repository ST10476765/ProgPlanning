﻿namespace part_two_API.Model
{//start of namespace
    public class User
    {//start of class

        public int UserID { get; set; }            // Primary Key
        public string UserName { get; set; }  // Personal details
        public string UserEmail { get; set; }
        public string Role { get; set; }     // "Organiser" or "Participant"
        public string HashedPassword { get; set; }  // Stored securely


    }//end of class

}//end of namespace
