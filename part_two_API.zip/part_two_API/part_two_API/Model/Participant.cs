﻿namespace part_two_API.Model
{//start of namespace
    public class Participant
    {//start of class

        public int ParticipantID { get; set; }
        public string ParticipantName { get; set; }
        public string CellNumber { get; set; }
        public string Email { get; set; }
        public string RaceNumber { get; set; }
        public int Age { get; set; }       // added for profile
        public string Gender { get; set; } // added for profile
        public int UserID { get; set; }    // Foreign key

    }//end of class


}//end of namespace
