﻿using part_two_API.Model;
using System.Data.SqlClient;
namespace part_two_API.Database
{//start of namespace
    public class CategoryDatabase
    {//start of class


        private string connection_string = @"Server=localhost\SQLEXPRESS;Database=Prog;Trusted_Connection=True;";

        public void CreateCategory(Category category)
        {
            using (SqlConnection conn = new SqlConnection(connection_string))
            {
                string query = @"INSERT INTO Category (CategoryDescription, Distance, OrganiserID)
                                 VALUES (@CategoryDescription, @Distance, @OrganiserID)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@CategoryDescription", category.CategoryDescription);
                cmd.Parameters.AddWithValue("@Distance", category.Distance);
                cmd.Parameters.AddWithValue("@OrganiserID", category.OrganiserID);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }//end of creatCategory

        public List<Category> GetAllCategories()
        {
            List<Category> categories = new List<Category>();
            using (SqlConnection conn = new SqlConnection(connection_string))
            {
                string query = "SELECT * FROM Category";
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    categories.Add(new Category
                    {
                        CategoryID = (int)reader["CategoryID"],
                        CategoryDescription = reader["CategoryDescription"].ToString(),
                        Distance = reader["Distance"].ToString(),
                        OrganiserID = (int)reader["OrganiserID"]
                    });
                }
            }
            return categories;

        }//end of getAllcategories









    }//end of class

}//end of namespace
