﻿using part_two_API.Model;
using System.Data.SqlClient;

namespace part_two_API.Database
{//start of namespace
    public class EventDatabase
    {//start of class


        private string connection_string = @"Server=localhost\SQLEXPRESS;Database=Prog;Trusted_Connection=True;";

        // View all events
        public List<Event> GetAllEvents()
        {
            List<Event> events = new List<Event>();
            using (SqlConnection connect = new SqlConnection(connection_string))
            {
                string query = "SELECT * FROM Event";
                SqlCommand cmd = new SqlCommand(query, connect);
                connect.Open();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        events.Add(new Event
                        {
                            EventID = Convert.ToInt32(reader["EventID"]),
                            EventName = reader["EventName"].ToString(),
                            EventDescription = reader["EventDescription"].ToString(),
                            EventType = reader["EventType"].ToString(),
                            EventDate = Convert.ToDateTime(reader["EventDate"]),
                            PlaceOfTheEvent = reader["PlaceOfTheEvent"].ToString(),
                            CategoryID = Convert.ToInt32(reader["CategoryID"]),
                            OrganiserID = Convert.ToInt32(reader["OrganiserID"])
                        });
                    }
                }
            }
            return events;
        }//end of get all events

        // Create event
        public string CreateEvent(Event ev)
        {
            string message;
            using (SqlConnection connect = new SqlConnection(connection_string))
            {
                string query = @"INSERT INTO Event (EventName, EventDescription, EventType, EventDate, PlaceOfTheEvent, CategoryID, OrganiserID)
                                 VALUES (@EventName, @EventDescription, @EventType, @EventDate, @PlaceOfTheEvent, @CategoryID, @OrganiserID)";
                SqlCommand cmd = new SqlCommand(query, connect);
                cmd.Parameters.AddWithValue("@EventName", ev.EventName);
                cmd.Parameters.AddWithValue("@EventDescription", ev.EventDescription);
                cmd.Parameters.AddWithValue("@EventType", ev.EventType);
                cmd.Parameters.AddWithValue("@EventDate", ev.EventDate);
                cmd.Parameters.AddWithValue("@PlaceOfTheEvent", ev.PlaceOfTheEvent);
                cmd.Parameters.AddWithValue("@CategoryID", ev.CategoryID);
                cmd.Parameters.AddWithValue("@OrganiserID", ev.OrganiserID);

                connect.Open();
                cmd.ExecuteNonQuery();
                message = "Event created successfully";
            }
            return message;
        }//end of create event

        //Update event
        public string UpdateEvent(Event ev)
        {
            string message;
            using (SqlConnection connect = new SqlConnection(connection_string))
            {
                string query = @"UPDATE Event 
                                 SET EventName=@EventName, EventDescription=@EventDescription, EventType=@EventType, 
                                     EventDate=@EventDate, PlaceOfTheEvent=@PlaceOfTheEvent, 
                                     CategoryID=@CategoryID, OrganiserID=@OrganiserID
                                 WHERE EventID=@EventID";

                SqlCommand cmd = new SqlCommand(query, connect);
                cmd.Parameters.AddWithValue("@EventName", ev.EventName);
                cmd.Parameters.AddWithValue("@EventDescription", ev.EventDescription);
                cmd.Parameters.AddWithValue("@EventType", ev.EventType);
                cmd.Parameters.AddWithValue("@EventDate", ev.EventDate);
                cmd.Parameters.AddWithValue("@PlaceOfTheEvent", ev.PlaceOfTheEvent);
                cmd.Parameters.AddWithValue("@CategoryID", ev.CategoryID);
                cmd.Parameters.AddWithValue("@OrganiserID", ev.OrganiserID);
                cmd.Parameters.AddWithValue("@EventID", ev.EventID);

                connect.Open();
                int rows = cmd.ExecuteNonQuery();
                message = rows > 0 ? "Event updated successfully" : "Event not found";
            }
            return message;
        }//end of update event

        //Delete event
        public string DeleteEvent(int eventId)
        {
            string message;
            using (SqlConnection connect = new SqlConnection(connection_string))
            {
                string query = "DELETE FROM Event WHERE EventID=@EventID";
                SqlCommand cmd = new SqlCommand(query, connect);
                cmd.Parameters.AddWithValue("@EventID", eventId);

                connect.Open();
                int rows = cmd.ExecuteNonQuery();
                message = rows > 0 ? "Event deleted successfully" : "Event not found";
            }
            return message;
        }
    




}//end of class


}//end of namespace
