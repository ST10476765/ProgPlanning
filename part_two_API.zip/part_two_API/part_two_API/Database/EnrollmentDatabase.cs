﻿using part_two_API.Model;
using System.Data.SqlClient;
namespace part_two_API.Database
{//start of namespace
    public class EnrollmentDatabase
    {//start of class

        private string connection_string = @"Server=localhost\SQLEXPRESS;Database=Prog;Trusted_Connection=True;";

        public void CreateEnrollment(Enrollment enrollment)
        {
            using (SqlConnection conn = new SqlConnection(connection_string))
            {
                string query = @"INSERT INTO Enrollment 
                                 (EnrollmentDate, EnrollmentStatus, UserID, EventID, CategoryID)
                                 VALUES (@EnrollmentDate, @EnrollmentStatus, @UserID, @EventID, @CategoryID)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@EnrollmentDate", enrollment.EnrollmentDate);
                cmd.Parameters.AddWithValue("@EnrollmentStatus", enrollment.EnrollmentStatus);
                cmd.Parameters.AddWithValue("@UserID", enrollment.UserID);
                cmd.Parameters.AddWithValue("@EventID", enrollment.EventID);
                cmd.Parameters.AddWithValue("@CategoryID", enrollment.CategoryID);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }//end of createEnrollment meth


        public List<Enrollment> GetEnrollmentsByEvent(int eventId)
        {
            List<Enrollment> enrollments = new List<Enrollment>();
            using (SqlConnection conn = new SqlConnection(connection_string))
            {
                string query = "SELECT * FROM Enrollment WHERE EventID = @EventID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@EventID", eventId);

                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    enrollments.Add(new Enrollment
                    {
                        EnrollmentID = (int)reader["EnrollmentID"],
                        EnrollmentDate = (DateTime)reader["EnrollmentDate"],
                        EnrollmentStatus = reader["EnrollmentStatus"].ToString(),
                        UserID = (int)reader["UserID"],
                        EventID = (int)reader["EventID"],
                        CategoryID = (int)reader["CategoryID"]
                    });
                }
            }
            return enrollments;
        }//end of getErollmentByEvent meth



    }//end of class
}//end of namepace
