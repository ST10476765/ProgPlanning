﻿using part_two_API.Model;
using System.Data.SqlClient;

namespace part_two_API.Database
{//start of namespace
    public class ResultDatabase
    {//start of class

        private string connection_string = @"Server=localhost\SQLEXPRESS;Database=Prog;Trusted_Connection=True;";

        public void CreateResult(Result result)
        {
            using (SqlConnection conn = new SqlConnection(connection_string))
            {
                string query = @"INSERT INTO Result (EnrollmentID, FinishTime,  PodiumPlacement)
                                 VALUES (@EnrollmentID, @FinishTime, @Position)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@EnrollmentID", result.EnrollmentID);
                cmd.Parameters.AddWithValue("@FinishTime", result.FinishTime);
                cmd.Parameters.AddWithValue("@Position", result.PodiumPlacement);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }// end of createResult meth


        public List<Result> GetResultsByParticipant(int userId)
        {
            List<Result> results = new List<Result>();
            using (SqlConnection connect = new SqlConnection(connection_string))
            {
                string query = @"SELECT r.ResultID, r.EnrollmentID, r.FinishTime, r.PodiumPlacement
                                 FROM Result r
                                 INNER JOIN Enrollment e ON r.EnrollmentID = e.EnrollmentID
                                 WHERE e.UserID = @UserID";
                SqlCommand cmd = new SqlCommand(query, connect);
                cmd.Parameters.AddWithValue("@UserID", userId);

                connect.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    results.Add(new Result
                    {
                        ResultID = (int)reader["ResultID"],
                        EnrollmentID = (int)reader["EnrollmentID"],
                        FinishTime = (TimeSpan)reader["FinishTime"],
                        PodiumPlacement = (int)reader["PodiumPlacement"]
                    });
                }
            }
            return results;
        }



    }//end of class
}//end of namespace
