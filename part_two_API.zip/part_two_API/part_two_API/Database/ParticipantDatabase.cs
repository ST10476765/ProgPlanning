﻿using part_two_API.Model;
using System.Data.SqlClient;

namespace part_two_API.Database
{//start of namespace
    public class ParticipantDatabase
    {//start of class

        private string connection_string = @"Server=localhost\SQLEXPRESS;Database=Prog;Trusted_Connection=True;";


        //View Participant Profile
        public Participant GetParticipantProfile(int userId)
        {//start of getParticipantProfile meth
            Participant participant = null;

            using (SqlConnection connect = new SqlConnection(connection_string))
            {
                string query = "SELECT * FROM Participant WHERE UserID=@UserID";
                SqlCommand cmd = new SqlCommand(query, connect);
                cmd.Parameters.AddWithValue("@UserID", userId);
                connect.Open();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        participant = new Participant
                        {
                            ParticipantID = Convert.ToInt32(reader["ParticipantID"]),
                            ParticipantName = reader["ParticipantName"].ToString(),
                            CellNumber = reader["CellNumber"].ToString(),
                            Email = reader["Email"].ToString(),
                            RaceNumber = reader["RaceNumber"].ToString(),
                            Age = reader["Age"] == DBNull.Value ? 0 : Convert.ToInt32(reader["Age"]),
                            Gender = reader["Gender"].ToString(),
                            UserID = Convert.ToInt32(reader["UserID"])
                        };
                    }
                }
            }
            return participant;

        }//end of getParticipantProfile meth



        //Update Participant Profile
        public string UpdateParticipantProfile(int userId, int age, string gender, string cellnumber)
        {
            string message = string.Empty;

            using (SqlConnection connect = new SqlConnection(connection_string))
            {
                string query = @"UPDATE Participant SET Age=@Age, Gender=@Gender, CellNumber=@CellNumber WHERE UserID=@UserID";
                SqlCommand cmd = new SqlCommand(query, connect);
                cmd.Parameters.AddWithValue("@Age", age);
                cmd.Parameters.AddWithValue("@Gender", gender);
                cmd.Parameters.AddWithValue("@UserID", userId);
                cmd.Parameters.AddWithValue("@CellNumber", cellnumber);
                connect.Open();

                int rows = cmd.ExecuteNonQuery();
                message = rows > 0 ? "Profile updated successfully" : "Profile not found";
            }

            return message;
        }


    }//end of class

}//end of namesapce
