﻿using part_two_API.Model;
using System.Data.SqlClient;
namespace part_two_API.Database
{//start of namespace
    public class OrganiserDatabase
    {//start of class

        private string connection_string = @"Server=localhost\SQLEXPRESS;Database=Prog;Trusted_Connection=True;";

        // View Organiser Profile
        public Organiser GetOrganiserProfile(int userId)
        {
            Organiser organiser = null;

            using (SqlConnection connect = new SqlConnection(connection_string))
            {
                string query = "SELECT * FROM Organiser WHERE UserID=@UserID";
                SqlCommand cmd = new SqlCommand(query, connect);
                cmd.Parameters.AddWithValue("@UserID", userId);
                connect.Open();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        organiser = new Organiser
                        {
                            OrganiserID = Convert.ToInt32(reader["OrganiserID"]),
                            OrganiserName = reader["OrganiserName"].ToString(),
                            CellNumber = reader["CellNumber"].ToString(),
                            Email = reader["Email"].ToString(),
                            Age = reader["Age"] == DBNull.Value ? 0 : Convert.ToInt32(reader["Age"]),
                            Gender = reader["Gender"].ToString(),
                            UserID = Convert.ToInt32(reader["UserID"])
                        };
                    }
                }
            }
            return organiser;
        }//END



        // Update Organiser Profile
        public string UpdateOrganiserProfile(int userId, int age, string gender, string cellnumber)
        {
            string message = string.Empty;

            using (SqlConnection connect = new SqlConnection(connection_string))
            {
                string query = @"UPDATE Organiser 
                                 SET Age=@Age, Gender=@Gender, CellNumber=@CellNumber 
                                 WHERE UserID=@UserID";
                SqlCommand cmd = new SqlCommand(query, connect);
                cmd.Parameters.AddWithValue("@Age", age);
                cmd.Parameters.AddWithValue("@Gender", gender);
                cmd.Parameters.AddWithValue("@CellNumber", cellnumber);
                cmd.Parameters.AddWithValue("@UserID", userId);
                connect.Open();

                int rows = cmd.ExecuteNonQuery();
                message = rows > 0 ? "Profile updated successfully" : "Profile not found";
            }

            return message;
        }



    }//end of class


}//end of namespace
